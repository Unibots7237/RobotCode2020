package frc.robot.subsystems;
/*
	Author: Mohamad and Mohammad
	Date: 1/29/2020
	Subject: Autonomous Period
*/

import frc.robot.*;

import com.ctre.phoenix.motorcontrol.SensorCollection;
import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.networktables.*;

public class Autonomous extends Subsystem{
	//Creating encoder objects
  public static SensorCollection encoder1 = new SensorCollection (DriveBase.left_front);
  public static SensorCollection encoder2 = new SensorCollection (DriveBase.left_back);
  public static SensorCollection encoder3 = new SensorCollection (DriveBase.right_front);
  public static SensorCollection encoder4 = new SensorCollection (DriveBase.right_back);

  

	public static void runAutonoumous(){
    int count = 100;
    boolean valid = false;
    while(true){
      count++;
      valid = limelight();
      SmartDashboard.putBoolean("Check", valid);
      if(valid && count >= 100)
      {
        shoot();
        count = 0;
      }
      Timer.delay(.05);
    }

  /*  Timer.delay(RobotMap.delay);
    adjustDistance();
    Timer.delay(.5);
    shoot();
    */
  //  moveRobot(70, 0, 0, .5); 
  // moveRobot(0, 0, 180, .5); 
	}

	private static void moveRobot(double x, double y, double z, double speed){//Moves robot coordinates x,y,z over (3*time) seconds
    double x_speed, y_speed, z_speed;
		x_speed = (x >= 0)? speed: -speed; 
		y_speed = (y >= 0)? speed: -speed; 
		z_speed = (z >= 0)? speed: -speed;
    x*=RobotMap.rPERCEN_X; //Ratios from unit to cm
    y*=RobotMap.rPERCEN_Y; //        ''
    z*=RobotMap.rPERCEN_Z; //        '

    resetEncoders();
		while (avgEncoder() < Math.abs(x))
      Robot.drivebase.teleopDrive(x_speed, 0, 0); // Need to add a correction factor thing here
    stopRobot();
		resetEncoders();
		while (avgEncoder() < Math.abs(y))
      Robot.drivebase.teleopDrive(0, -y_speed,0);
    stopRobot();
		resetEncoders();
		while (avgEncoder() < Math.abs(z))
      Robot.drivebase.teleopDrive(0, 0,z_speed);
    stopRobot();
    resetEncoders();
  }


  public static double avgEncoder ()
  {
      return (Math.abs(encoder1.getQuadraturePosition()) + 
              Math.abs(encoder2.getQuadraturePosition()) +
              Math.abs(encoder3.getQuadraturePosition()) +
              Math.abs(encoder4.getQuadraturePosition())) / 4.0;
  }

  public static void stopRobot(){
    Robot.drivebase.teleopDrive(0, 0, 0);
    Timer.delay(.2);
  }

  public static void shoot(){
    Robot.conveyorBelt.forward();
    Robot.launcher.Shoot();
    Timer.delay(.85);  
    Robot.conveyorBelt.stop();
    Robot.launcher.stop();
  }

	public void initDefaultCommand(){
  }

  public static void resetEncoders() {
    encoder1.setQuadraturePosition(0,0);
    encoder2.setQuadraturePosition(0,0);
    encoder3.setQuadraturePosition(0,0);
    encoder4.setQuadraturePosition(0,0);
  }
  public static void adjustDistance(){
    boolean check = true;
  for (int count = 0; count<3; count++){
    check = true;
    while(check){
      if (Math.abs(((Robot.ultrasonic.getValue())*RobotMap.sMeters))>(RobotMap.sError+RobotMap.sDistance))
        if (((((Robot.ultrasonic.getValue())*RobotMap.sMeters))-RobotMap.sDistance)>.3)
          Robot.drivebase.teleopDrive(0,-.2,0);
        else 
        Robot.drivebase.teleopDrive(0,-.125,0);
      else if (Math.abs(((Robot.ultrasonic.getValue())*RobotMap.sMeters))<(RobotMap.sDistance-RobotMap.sError))
        if (((((Robot.ultrasonic.getValue())*RobotMap.sMeters))-RobotMap.sDistance)<-.3)
          Robot.drivebase.teleopDrive(0,.2,0);
        else 
          Robot.drivebase.teleopDrive(0,.125,0);
      else{
        Robot.drivebase.teleopDrive(0,0,0);
        check = false;
      }      
      Timer.delay(.01);
  }
  }
}
  public static boolean limelight(){
    NetworkTable table = NetworkTableInstance.getDefault().getTable("limelight");
    NetworkTableEntry tv = table.getEntry("tv");
    NetworkTableEntry tx = table.getEntry("tx");
    NetworkTableEntry ty = table.getEntry("ty");
    NetworkTableEntry ta = table.getEntry("ta");
    NetworkTableEntry ta1 = table.getEntry("ta1");
    NetworkTableEntry ta2 = table.getEntry("ta2");

    double x = tx.getDouble(0.0);
    double y = ty.getDouble(0.0);
    double area = ta.getDouble(0.0);
    double a2 = ta2.getDouble(0.0);
    //double distance = (4) / Math.tan(a1+a2);
    double v = tv.getDouble(0.0);
    SmartDashboard.putNumber("tx", tx.getDouble(0.0));//OI must be the last object declared
    SmartDashboard.putNumber("ty", ty.getDouble(0.0));
    SmartDashboard.putNumber("area", ta.getDouble(0.0));
    SmartDashboard.putNumber("v", tv.getDouble(0.0));
    double dist = 0;
    double angle = 0;
    double base = 0;
    double good = 0;
    double dir=0;
    

    final double MAX_DISTANCE = 8.5;
    final double MIN_DISTANCE = 7.5;
    final double AREA_OFFSET = 1;
    final double XY_OFFSET = 3;
    final double MAX_AREA = 5;

    if( v == 1){
      //Determine forward or backward direction
      if(area > MAX_AREA + AREA_OFFSET)
        dir = -1;
      else if(area < MAX_AREA - AREA_OFFSET)
        dir = 1;
      else{
        dir = 0;
      }
    }
    else  dir = 0;
       

      //dist = (area > 12 || area < 8) ? Math.cbrt(area - MAX_AREA) / Math.cbrt(30) : 0;
      dist = -Math.abs(Math.cbrt(((Math.pow(((10-area)/100), 2)))))*dir*1;
      SmartDashboard.putNumber("dist", dist);
      angle = (x > XY_OFFSET || x < -XY_OFFSET) ? Math.cbrt(x) / 3 : 0; //Constrains value between -1 and 1
    

    Robot.drivebase.teleopDrive(0,dist, angle/3);
    if(angle == 0 && dist == 0 && v == 1)
      return true;
    else
      return false;
  }

  @Override
  public void periodic() {
    // This method will be called once per scheduler run
  }
}
